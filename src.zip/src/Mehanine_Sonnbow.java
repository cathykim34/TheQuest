public class Mehanine_Sonnbow extends Warrior {
    public Mehanine_Sonnbow(){
        super("Mehanine_Sonnbow", 600, 700, 800, 500, 2500, 8);
    }
}
