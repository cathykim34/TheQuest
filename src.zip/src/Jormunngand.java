public class Jormunngand extends Spirit{
    public Jormunngand(){
        super("Jormunngand", 8, 600, 900, 20);
    }
}
