public class Sword extends Weaponry {
    public Sword(){
        super("Sword", 500, 1, 800, 1);
    }
}
