public class Cyrrollalee extends Exoskeleton {
    public Cyrrollalee(){
        super("Cyrrollalee", 7, 700, 800, 75);
    }
}
