public class Sehanine_Moonbow extends Paladin {
    public Sehanine_Moonbow(){
        super("Sehanine_Moonbow", 300, 750, 700, 700, 2500, 7);
    }
}
