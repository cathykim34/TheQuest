public class Taltecuhtli extends Spirit {
    public Taltecuhtli(){
        super("Taltecuhtli", 10, 300, 200, 50);
    }
}
