public class FallenAngel extends Spirit {
    public FallenAngel(){
        super("FallenAngel", 5, 800, 700, 50);
    }
}
