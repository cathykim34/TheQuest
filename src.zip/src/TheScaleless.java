public class TheScaleless extends Dragon {
    public TheScaleless(){
        super("TheScaleless", 7, 700, 600, 75);
    }
}
