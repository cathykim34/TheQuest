public class Natsunomeryu extends Dragon {
    public Natsunomeryu(){
        super("Natsunomeryu", 1, 100, 200, 10);
    }
}
