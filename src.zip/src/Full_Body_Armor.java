public class Full_Body_Armor extends Armory {
    public Full_Body_Armor(){
        super("Full Body Armor", 1000, 8, 1100);
    }
}
