public class Andrealphus extends Spirit {
    public Andrealphus(){
        super("Andrealphus", 2, 600, 500, 40);
    }
}
