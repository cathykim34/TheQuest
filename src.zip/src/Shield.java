public class Shield extends Weaponry {
    public Shield(){
        super("Shield", 400, 1, 100, 1);
    }
}
