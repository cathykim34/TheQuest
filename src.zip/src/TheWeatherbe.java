public class TheWeatherbe extends Dragon {
    public TheWeatherbe(){
        super("TheWeatherbe", 8, 800, 900, 80);
    }
}
