public class Chiang_shih extends Spirit {
    public Chiang_shih(){
        super("Chiang_shih", 4, 700, 600, 40);
    }
}
