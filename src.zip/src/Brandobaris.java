public class Brandobaris extends Exoskeleton {
    public Brandobaris(){
        super("Brandobaris", 3, 350, 450, 30);
    }
}
