public class Rillifane_Rallathil extends Sorcerer {
    public Rillifane_Rallathil(){
        super("Rillifane_Rallathil", 1300, 750, 450, 500, 2500, 9);
    }
}
