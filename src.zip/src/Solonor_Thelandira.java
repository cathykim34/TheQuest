public class Solonor_Thelandira extends Paladin {
    public Solonor_Thelandira(){
        super("Solonor_Thelandira", 300, 750, 650, 700, 2500, 7);
    }
}
