public class Ice_Blade extends IceSpell {
    public Ice_Blade(){
        super("Ice_Blade", 250, 1, 450, 100);
    }
}
