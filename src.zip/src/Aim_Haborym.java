public class Aim_Haborym extends Spirit {
    public Aim_Haborym(){
        super("Aim_Haborym", 1, 450, 350, 35);
    }
}
