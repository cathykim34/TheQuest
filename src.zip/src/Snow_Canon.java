public class Snow_Canon extends IceSpell {
    public Snow_Canon(){
        super("Snow_Canon ", 500, 2, 650, 250);
    }
}
