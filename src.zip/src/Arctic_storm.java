public class Arctic_storm extends IceSpell {
    public Arctic_storm(){
        super("Arctic_storm", 700, 6, 800, 300);
    }
}
