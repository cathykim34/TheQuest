public class Bow extends Weaponry {
    public Bow(){
        super("Bow", 300, 2, 500, 2);
    }
}
