public class Heat_Wave extends FireSpell {
    public Heat_Wave(){
        super("Heat_Wave", 450, 2, 600, 150);
    }
}
