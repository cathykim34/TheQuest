public class St_Yeenoghu extends Exoskeleton {
    public St_Yeenoghu(){
        super("St_Yeenoghu", 9, 950, 850, 90);
    }
}
