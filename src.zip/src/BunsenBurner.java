public class BunsenBurner extends Dragon {
    public BunsenBurner(){
        super("BunsenBurner", 4, 400, 500, 45);
    }
}
