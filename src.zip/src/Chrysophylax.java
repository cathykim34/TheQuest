public class Chrysophylax extends Dragon {
    public Chrysophylax(){
        super("Chrysophylax", 2, 200, 500, 20);
    }
}
