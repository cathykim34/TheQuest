public class D_Maleficent extends Dragon {
    public D_Maleficent(){
        super("D_Maleficent", 9, 900, 950, 85);
    }
}
