public class Aasterinian extends Exoskeleton {
    public Aasterinian(){
        super("Aasterinian", 4, 400, 500, 45);
    }
}
