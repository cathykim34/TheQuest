public class LightningDagger extends LightningSpell {
    public LightningDagger(){
        super("LightningDagger", 400, 1, 500, 150);
    }
}
