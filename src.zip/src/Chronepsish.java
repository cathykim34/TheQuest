public class Chronepsish extends Exoskeleton {
    public Chronepsish(){
        super("Chronepsish", 6, 650, 750, 60);
    }
}
