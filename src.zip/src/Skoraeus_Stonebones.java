public class Skoraeus_Stonebones extends Paladin {
    public Skoraeus_Stonebones(){
        super("Skoraeus_Stonebones", 250, 650, 600, 350, 2500, 4);
    }
}
