public class Thunder_Blast extends LightningSpell {
    public Thunder_Blast(){
        super("Thunder_Blast", 750, 4, 950, 400);
    }
}
