public class Breath_of_Fire extends FireSpell {
    public Breath_of_Fire(){
        super("Breath_of_Fire", 350, 1, 450, 100);
    }
}
