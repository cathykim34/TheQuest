public class Phaarthurnax extends Dragon {
    public Phaarthurnax(){
        super("Phaarthurnax", 6, 600, 700, 60);
    }
}
