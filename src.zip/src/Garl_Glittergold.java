public class Garl_Glittergold extends Paladin {
    public Garl_Glittergold(){
        super("Garl_Glittergold", 100, 600, 500, 400, 2500, 5);
    }
}
