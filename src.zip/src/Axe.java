public class Axe extends Weaponry {
    public Axe(){
        super("Axe", 550, 5, 850, 1);
    }
}
