public class Platinum_Shield extends Armory {
    public Platinum_Shield(){
        super("Platinum_Shield", 150, 1, 200);
    }
}
