public class Lava_Commet extends FireSpell {
    public Lava_Commet(){
        super("Lava_Commet", 800, 7, 1000, 550);
    }
}
