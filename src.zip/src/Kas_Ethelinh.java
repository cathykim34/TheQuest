public class Kas_Ethelinh extends Dragon{
    public Kas_Ethelinh(){
        super("Kas_Ethelinh", 5, 600, 500, 60);
    }
}
