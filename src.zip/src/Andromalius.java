public class Andromalius extends Spirit {
    public Andromalius(){
        super("Andromalius", 3, 550, 450, 25);
    }
}
