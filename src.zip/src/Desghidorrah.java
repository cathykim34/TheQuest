public class Desghidorrah extends Dragon {
    public Desghidorrah(){
        super("Desghidorrah", 3, 300, 400, 35);
    }
}
