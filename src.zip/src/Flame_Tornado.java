public class Flame_Tornado extends FireSpell {
    public Flame_Tornado(){
        super("Flame_Tornado", 700, 4, 850, 300);
//        super.fireSpells.add(this);
    }
}
