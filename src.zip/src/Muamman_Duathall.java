public class Muamman_Duathall extends Warrior {
    public Muamman_Duathall(){
        super("Muamman_Duathall", 300, 900, 500, 750, 2546, 6);
    }
}
