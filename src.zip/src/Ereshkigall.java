public class Ereshkigall extends Spirit {
    public Ereshkigall(){
        super("Ereshkigall", 6, 950, 450, 35);
    }
}
