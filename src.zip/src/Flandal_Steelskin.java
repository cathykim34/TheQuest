public class Flandal_Steelskin extends Warrior {
    public Flandal_Steelskin(){
        super("Flandal_Steelskin", 200, 750, 650, 700, 2500, 7);
    }
}
