public class BigBad_Wolf extends Exoskeleton {
    public BigBad_Wolf(){
        super("BigBad_Wolf", 1, 150, 250, 15);
    }
}
