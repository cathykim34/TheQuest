public class Alexstraszan extends Dragon {
    public Alexstraszan(){
        super("Alexstraszan", 10, 1000, 9000, 55);
    }
}
