public class Wizard_Shield extends Armory{
    public Wizard_Shield(){
        super("Wizard Shield", 1200, 10, 1500);
    }
}
