public abstract class Characters {
    public abstract void currentStats();
}
