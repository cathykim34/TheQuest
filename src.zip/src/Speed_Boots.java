public class Speed_Boots extends Armory {
    public Speed_Boots(){
        super("Speed Boots", 550, 4, 600);
    }
}
