public class St_Shargaas extends Exoskeleton {
    public St_Shargaas(){
        super("St_Shargaas", 5, 550, 650, 55);
    }
}
