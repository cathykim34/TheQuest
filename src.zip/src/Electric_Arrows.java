public class Electric_Arrows extends LightningSpell {
    public Electric_Arrows(){
        super("Electric_Arrows", 550, 5, 650, 200);
    }
}
