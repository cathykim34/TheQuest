public class Breastplate extends Armory {
    public Breastplate(){
        super("Breastplate", 350, 3, 600);
    }
}
