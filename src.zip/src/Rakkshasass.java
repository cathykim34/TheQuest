public class Rakkshasass extends Spirit {
    public Rakkshasass(){
        super("Rakkshasass", 9, 550, 600, 35);
    }
}
