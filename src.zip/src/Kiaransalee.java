public class Kiaransalee extends Exoskeleton {
    public Kiaransalee(){
        super("Kiaransalee", 8, 850, 950, 85);
    }
}
