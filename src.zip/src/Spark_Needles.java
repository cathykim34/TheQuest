public class Spark_Needles extends LightningSpell {
    public Spark_Needles(){
        super("Spark_Needles", 500, 2, 600, 200);
    }
}
