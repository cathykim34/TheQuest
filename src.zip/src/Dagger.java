public class Dagger extends Weaponry{
    public Dagger(){
        super("Dagger", 200, 1, 250, 1);
    }

}
