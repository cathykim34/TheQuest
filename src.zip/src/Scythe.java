public class Scythe extends Weaponry {
    public Scythe(){
        super("Scythe", 1000, 6, 1100, 2);
    }
}
