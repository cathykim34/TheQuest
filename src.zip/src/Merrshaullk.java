public class Merrshaullk extends Exoskeleton {
    public Merrshaullk(){
        super("Merrshaullk", 10, 1000, 900, 55);
    }
}
