public class Carl_Clittercold extends Sorcerer {
    public Carl_Clittercold(){
        super("Carl_Clittercold", 700, 550, 600, 500, 2500, 7);
    }
}
