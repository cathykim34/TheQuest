public class Gaerdal_Ironhand extends Warrior {
    public Gaerdal_Ironhand(){
        super("Gaerdal_Ironhand", 100, 700, 500, 600, 1354, 7);
    }
}
