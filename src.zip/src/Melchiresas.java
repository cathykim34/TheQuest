public class Melchiresas extends Spirit {
    public Melchiresas(){
        super("Melchiresas", 7, 350, 150, 75);
    }
}
