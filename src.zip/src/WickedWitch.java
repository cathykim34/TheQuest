public class WickedWitch extends Exoskeleton {
    public WickedWitch(){
        super("WickedWitch", 2, 250, 350, 25);
    }
}
