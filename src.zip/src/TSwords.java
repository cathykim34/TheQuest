public class TSwords extends Weaponry {
    public TSwords(){
        super("TSwords", 1400, 8, 1600, 2);
    }
}
