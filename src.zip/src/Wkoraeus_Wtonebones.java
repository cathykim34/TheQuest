public class Wkoraeus_Wtonebones extends Sorcerer {
    public Wkoraeus_Wtonebones(){
        super("Wkoraeus_Wtonebones", 800, 850, 600, 450, 2500, 6);
    }
}
