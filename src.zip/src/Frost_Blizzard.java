public class Frost_Blizzard extends IceSpell{
    public Frost_Blizzard(){
        super("Frost_Blizzard", 750, 5, 850, 350);
    }
}
